// Dynamic year and easy config
document.getElementById('year').textContent = new Date().getFullYear();

// Update QR when you set your real site URL:
const SITE_URL = 'https://ВАШ_НИК.github.io/firenox-site/'; // <-- замените на реальный адрес после публикации
// Подсказка: QR-код в assets/qr-universal.png можно перегенерировать любым генератором по адресу SITE_URL.
